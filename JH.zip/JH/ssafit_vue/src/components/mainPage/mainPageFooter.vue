<template>
  <div>
    <footer class="text-body-secondary py-5">
  <div class="container">
    <p class="float-end mb-1">
      <a href="#">Back to top</a>
    </p>
    <p class="mb-1">&copy; SSAFIT Project/대전3반/김준혁,하상진</p>
  </div>
</footer>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>