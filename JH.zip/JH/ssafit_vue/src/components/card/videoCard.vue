<template>
    <div class="card shadow-sm">
            <svg class="bd-placeholder-img card-img-top" 
                width="100%" 
                height="225" 
                xmlns="http://www.w3.org/2000/svg" 
                role="img" 
                aria-label="Placeholder: Thumbnail" 
                preserveAspectRatio="xMidYMid slice" 
                focusable="false">
            <title>Placeholder</title>
            <rect
                width="100%" 
                height="100%" 
                fill="#55595c"/>
            <text
                x="50%" y="50%" 
                fill="#eceeef"
                dy=".3em">
            <a href="https://www.youtube.com/watch?v=3wXPGc2lI8Q&t=344s"/>흑자</text>
            </svg>

            <div class="card-body">
              <p class="card-text">영상 설명이 들어갈 부분</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">리뷰</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">관련 상품</button>
                </div>
                <small class="text-body-secondary">9 mins</small>
              </div>
            </div>
          </div>
</template>

<script setup>

</script>

<style scoped>

</style>