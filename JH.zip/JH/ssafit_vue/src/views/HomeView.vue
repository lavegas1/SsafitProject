<template>
  <div class="text-center">
    <h2>SSAFIT Project</h2>
    <mainPageHeader/>
    <mainPage/>
    <mainPageFooter/>
  </div>
</template>

<script setup>
  import mainPage from '@/components/mainPage/mainPage.vue';
  import mainPageHeader from '@/components/mainPage/mainPageHeader.vue';
  import mainPageFooter from '@/components/mainPage/mainPageFooter.vue';
</script>


<style scoped>

</style>
