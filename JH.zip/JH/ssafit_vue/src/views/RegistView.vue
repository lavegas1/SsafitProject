<template>
    <div>
        <UserCreate/>
    </div>
</template>

<script setup>
import UserCreate from '@/components/user/UserCreate.vue'

</script>

<style scoped>

</style>