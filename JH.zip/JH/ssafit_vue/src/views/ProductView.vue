<template>
    <div>
        <ProductList/>
    </div>
</template>

<script setup>
import ProductList from '@/components/product/ProductList.vue';


</script>

<style scoped>

</style>