<template>
    <div>
      <h4>리뷰 뷰 입니다</h4>
    </div>
  </template>
  
  <script setup>
  </script>
  
  <style scoped></style>
  