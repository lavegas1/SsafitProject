<template>
    <div>
        <LoginForm/> 
    </div>
</template>

<script setup>
import LoginForm from '@/components/LoginForm/LoginForm.vue';

</script>

<style scoped>

</style>