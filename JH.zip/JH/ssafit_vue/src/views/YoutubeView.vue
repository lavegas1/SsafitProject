<template>
  <div class="container">
    <hr>
    <h2 class="text-center">SSAFIT Project</h2>
    <YoutubeVideoSearch/>
    <YoutubeVideoDetail/>
    <hr>
    <YoutubeVideoList/>
  </div>
</template>

<script setup>
import YoutubeVideoSearch from '@/components/youtube/YoutubeVideoSearch.vue'
import YoutubeVideoList from '@/components/youtube/YoutubeVideoList.vue'
import YoutubeVideoDetail from '@/components/youtube/YoutubeVideoDetail.vue'



</script>

<style scoped></style>
